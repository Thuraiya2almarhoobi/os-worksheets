#ifndef INCLUDE_HARDWARE_INTERRUPT_ENABLER_H
#define INCLUDE_HARDWARE_INTERRUPT_ENABLER_H

void enable_hardware_interrupts();
void disable_hardware_interrupts();

#endif /* INCLUDE_HARDWARE_INTERRUPT_ENABLER_H */
